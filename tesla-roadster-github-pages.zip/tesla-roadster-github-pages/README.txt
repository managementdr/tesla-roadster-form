TESLA ROADSTER INTEREST FORM — GITHUB PAGES

This folder is prepared for GitHub Pages.

PUBLISH STEPS
1. Sign in to https://github.com/ and create a new public repository.
2. Name it: tesla-roadster-form
3. Upload index.html from this folder to the repository root.
4. Open the repository Settings > Pages.
5. Under Build and deployment, choose Deploy from a branch.
6. Select branch: main; folder: /(root); click Save.
7. Wait for GitHub Pages to publish. Your site URL will appear in Settings > Pages.

IMPORTANT
This is an independent informational interest form, not an official Tesla order or giveaway page. GitHub Pages hosts static files only. The current form does not transmit submissions or email responses. Do not collect passwords, payment details, cryptocurrency wallet details, or other sensitive information.
